# Counterfactual framing (protocol section 7.2)

These counterfactuals are a **supplementary sensitivity analysis**, not a primary study contribution or a causal effect estimate.

- **Modifiable:** ANC visits, media exposure, insurance.
- **Semi-modifiable:** distance-is-a-problem, framed as service-deployment scenarios.
- **Immutable:** age, education, wealth, urban/rural, region.

The analysis uses complete-case observations. No missing-value imputation or missing-value category is introduced.

All SHAP and counterfactual outputs are model-derived associational estimates from a cross-sectional, observational design — NOT causal effect estimates.

