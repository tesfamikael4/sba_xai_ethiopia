# scenario1: Combined 2016+2024/25 � 80/20 split

Both survey rounds pooled into a single analytic file, then split 80/20 by cluster (never by row, to avoid leaking correlated births from the same enumeration area across the split). Train and test sets each contain a mix of both rounds.

## Metrics

| metric | value |
|---|---|
| n_train | 9000 |
| n_test | 2230 |
| train_prevalence | 0.4790 |
| test_prevalence | 0.4525 |
| roc_auc | 0.8693 |
| average_precision | 0.8583 |
| precision | 0.7651 |
| recall | 0.7651 |
| f1 | 0.7651 |
| brier_score | 0.1463 |
