# scenario4: 2016 only � train 80%, test 20%

Trained and tested entirely within the 2016 round, using the cluster-level 80/20 geographic hold-out already assigned by step06_survey_design.py for the 2016 round (config_2016.yaml, validation.geographic_holdout_fraction=0.2).

## Metrics

| metric | value |
|---|---|
| n_train | 3384 |
| n_test | 906 |
| train_prevalence | 0.3218 |
| test_prevalence | 0.3046 |
| roc_auc | 0.8137 |
| average_precision | 0.7041 |
| precision | 0.5873 |
| recall | 0.6703 |
| f1 | 0.6261 |
| brier_score | 0.1632 |
