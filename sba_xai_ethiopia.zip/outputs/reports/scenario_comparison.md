# Scenario comparison: 2016 vs 2024/25 EDHS

All 5 scenarios use the SAME model (algorithm + hyperparameters, config.model) so the comparison isolates the effect of which data the model trains/tests on. See each `outputs/reports/scenarioN/` folder for the full write-up.

| scenario | description | n_train | n_test | train_prevalence | test_prevalence | roc_auc | average_precision | precision | recall | f1 | brier_score |
|---|---|---|---|---|---|---|---|---|---|---|---|
| scenario1 | Combined 2016+2024/25, 80/20 cluster split | 9000 | 2230 | 0.4790 | 0.4525 | 0.8693 | 0.8583 | 0.7651 | 0.7651 | 0.7651 | 0.1463 |
| scenario2 | Train ALL 2024/25, test ALL 2016 | 6940 | 4290 | 0.5699 | 0.3182 | 0.8331 | 0.7258 | 0.6179 | 0.6989 | 0.6559 | 0.1586 |
| scenario3 | Train ALL 2016, test ALL 2024/25 | 4290 | 6940 | 0.3182 | 0.5699 | 0.8543 | 0.8887 | 0.7927 | 0.8063 | 0.7994 | 0.1542 |
| scenario4 | 2016 only, 80% train / 20% test | 3384 | 906 | 0.3218 | 0.3046 | 0.8137 | 0.7041 | 0.5873 | 0.6703 | 0.6261 | 0.1632 |
| scenario5 | 2024/25 only, 80% train / 20% test | 5614 | 1326 | 0.5549 | 0.6335 | 0.8747 | 0.9212 | 0.8513 | 0.7976 | 0.8236 | 0.1401 |

## Caveats
- All metrics are model-derived predictive-performance estimates from cross-sectional, observational data � not causal effect estimates (protocol section 9).
- region_stratum is encoded with a single canonical mapping shared by both rounds (see step12_scenario_comparison.py docstring) � NOT the per-round codes in each round's own outputs/by_round/<year>/tables/region_stratum_code_map.json.
- Scenarios 2 and 3 test generalization ACROSS survey rounds; a performance drop relative to scenarios 4/5 reflects genuine distribution shift between rounds (population change, question/coding differences), not model quality alone.
- Verify config_2016.yaml's `region_labels` and the b19<=35 eligibility-window assumption against the actual 2016 .DO/.MAP files before treating these numbers as final (see that config's inline `# 2016:` / VERIFY comments).
