# scenario3: Train on 2016, test on 2024/25

Model fit on the ENTIRE 2016 round, evaluated on the entire 2024/25 round as a fully out-of-round test set. Tests whether a model built on the older round generalizes forward to the current round.

## Metrics

| metric | value |
|---|---|
| n_train | 4290 |
| n_test | 6940 |
| train_prevalence | 0.3182 |
| test_prevalence | 0.5699 |
| roc_auc | 0.8543 |
| average_precision | 0.8887 |
| precision | 0.7927 |
| recall | 0.8063 |
| f1 | 0.7994 |
| brier_score | 0.1542 |
