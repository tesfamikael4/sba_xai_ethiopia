# scenario2: Train on 2024/25, test on 2016

Model fit on the ENTIRE 2024/25 round, evaluated on the entire 2016 round as a fully out-of-round test set. Tests whether a model built on the most recent data generalizes backward to the earlier round.

## Metrics

| metric | value |
|---|---|
| n_train | 6940 |
| n_test | 4290 |
| train_prevalence | 0.5699 |
| test_prevalence | 0.3182 |
| roc_auc | 0.8331 |
| average_precision | 0.7258 |
| precision | 0.6179 |
| recall | 0.6989 |
| f1 | 0.6559 |
| brier_score | 0.1586 |
