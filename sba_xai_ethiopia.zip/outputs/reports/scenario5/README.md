# scenario5: 2024/25 only � train 80%, test 20%

Trained and tested entirely within the 2024/25 round, using the cluster-level 80/20 geographic hold-out already assigned by step06_survey_design.py for the 2024/25 round (config.yaml, validation.geographic_holdout_fraction=0.2). Equivalent to the single-round result already reported in outputs/tables/holdout_metrics.json.

## Metrics

| metric | value |
|---|---|
| n_train | 5614 |
| n_test | 1326 |
| train_prevalence | 0.5549 |
| test_prevalence | 0.6335 |
| roc_auc | 0.8747 |
| average_precision | 0.9212 |
| precision | 0.8513 |
| recall | 0.7976 |
| f1 | 0.8236 |
| brier_score | 0.1401 |
